package com.example.a7_2_projectthree_helmersjarrod;

import android.content.ContentValues;
import android.database.sqlite.SQLiteDatabase;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;

public class WeightEntryActivity extends AppCompatActivity {

    private DatabaseHelper dbHelper;
    private EditText weightInput, dateInput;
    private Button saveWeight, cancel;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.WeightEntry);

        dbHelper = new DatabaseHelper(this);
        weightInput = findViewById(R.id.weightInput);
        dateInput = findViewById(R.id.dateInput);
        saveWeight = findViewById(R.id.saveWeight);
        cancel = findViewById(R.id.cancel);

        saveWeight.setOnClickListener(v -> saveWeightEntry());
        cancel.setOnClickListener(v -> finish());
    }

    private void saveWeightEntry() {
        String weight = weightInput.getText().toString();
        String date = dateInput.getText().toString();

        if (!weight.isEmpty() && !date.isEmpty()) {
            SQLiteDatabase db = dbHelper.getWritableDatabase();
            ContentValues values = new ContentValues();
            values.put("weight", Double.parseDouble(weight));
            values.put("date", date);
            db.insert("weight_records", null, values);
            db.close();
            Toast.makeText(this, "Weight Saved", Toast.LENGTH_SHORT).show();
            finish();
        } else {
            Toast.makeText(this, "Please fill in all fields", Toast.LENGTH_SHORT).show();
        }
    }
}
