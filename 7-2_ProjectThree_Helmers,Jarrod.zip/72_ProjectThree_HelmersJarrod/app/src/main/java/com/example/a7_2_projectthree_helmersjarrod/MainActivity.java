package com.example.a7_2_projectthree_helmersjarrod;

import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.os.Bundle;
import android.widget.TextView;
import androidx.appcompat.app.AppCompatActivity;

public class MainActivity extends AppCompatActivity {

    private DatabaseHelper dbHelper;
    private TextView weightRecords;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        dbHelper = new DatabaseHelper(this);
        weightRecords = findViewById(R.id.weightRecords);
        displayWeightRecords();
    }

    private void displayWeightRecords() {
        SQLiteDatabase db = dbHelper.getReadableDatabase();
        Cursor cursor = db.query("weight_records", null, null, null, null, null, null);

        StringBuilder builder = new StringBuilder();
        while (cursor.moveToNext()) {
            double weight = cursor.getDouble(cursor.getColumnIndex("weight"));
            String date = cursor.getString(cursor.getColumnIndex("date"));
            builder.append("Weight: ").append(weight).append(" | Date: ").append(date).append("\n");
        }
        weightRecords.setText(builder.toString());
        cursor.close();
        db.close();
    }
}